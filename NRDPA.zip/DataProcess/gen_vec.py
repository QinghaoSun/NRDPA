#-*-coding:utf-8 -*-

import csv
import json
import os
import re
import pickle
import numpy as np
import pandas as pd
from gensim.models import Word2Vec
from gensim.test.utils import common_texts, get_tmpfile


DATA_PATH_MUSIC     = "D:\\Resource\\Datas\\Model\\Test\\Digital_Music_5\\Digital_Music_5.json"
DATA_PATH_Instrument    = "D:\\Resource\\Datas\\Model\\Test\\Musical_Instruments_5\\Musical_Instruments_5.json"
DATA_PATH_Game    = "D:\\Resource\\Datas\\Model\\Test\\Video_Games_5\\Video_Games_5.json"
DATA_PATH_Product = "D:\\Resource\\Datas\\Model\\Test\\Office_Products_5\\Office_Products_5.json"
DATA_PATH_Food = "D:\\Resource\\Datas\\Model\\Test\\Grocery_and_Gourmet_Food_5\\Grocery_and_Gourmet_Food_5.json"

def main(path):
    sentences    = []
    user_reviews = pickle.load(open(path.replace('.json', 'user_review'), 'rb'))
    item_reviews = pickle.load(open(path.replace('.json', 'item_review'), 'rb'))
    u_text       = []
    i_text       = []
    for urid, review in user_reviews.items():
        for sen in review:
            line_cleaned = clean_str(sen).split(' ')
            u_text.append(line_cleaned)

    for irid, review in item_reviews.items():
        for sen in review:
            line_cleaned = clean_str(sen).split(' ')
            i_text.append(line_cleaned)

    with open(path) as f:
        for line in f:
            line = line.strip()
            info = json.loads(line)

            #个人修改
            if 'reviewText' not in info:
                continue

            sentences.append(info['reviewText'].split(' '))
    sentences += u_text
    sentences += i_text
    model = Word2Vec(sentences, size=100, window=3, min_count=1, workers=3)
    model.save(path.replace('.json', '.model'))
    del sentences
    del model
    del u_text
    del i_text
    print(path + " OVER")

def clean_str(string):
    string = re.sub(r"[^A-Za-z]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()

if __name__ == "__main__":
    #main(DATA_PATH_MUSIC)
    #main(DATA_PATH_Instrument)
    #main(DATA_PATH_Game)
    #main(DATA_PATH_Product)
    main(DATA_PATH_Food)