#-*-coding:utf-8 -*-

import csv
import json
import os
import pickle
import re
import numpy as np
import pandas as pd
from gensim.models import Word2Vec

DATA_PATH_MUSIC     = "E:\\Datas\\Model\\Test\\Digital_Music_5\\Digital_Music_5.json"
DATA_PATH_Instrument    = "E:\\Datas\\Model\\Test\\Musical_Instruments_5\\Musical_Instruments_5.json"
DATA_PATH_Game    = "E:\\Datas\\Model\\Test\\Video_Games_5\\Video_Games_5.json"
DATA_PATH_Product = "E:\\Datas\\Model\\Test\\Office_Products_5\\Office_Products_5.json"
DATA_PATH_Food = "E:\\Datas\\Model\\Test\\Grocery_and_Gourmet_Food_5\\Grocery_and_Gourmet_Food_5.json"
PADDING_WORD        = "<PAD/>"
REVIEW_SIZE         = 300

def main(path):
    user_reviews = pickle.load(open(path.replace('.json', 'user_review'), 'rb'))
    train_user_reviews = pickle.load(open(path.replace('.json', 'train_user_review'), 'rb'))
    item_reviews = pickle.load(open(path.replace('.json', 'item_review'), 'rb'))
    train_item_reviews = pickle.load(open(path.replace('.json', 'train_item_review'), 'rb'))

    user_rid = pickle.load(open(path.replace('.json', 'user_rid'), 'rb'))
    train_user_rid = pickle.load(open(path.replace('.json', 'train_user_rid'), 'rb'))
    item_rid = pickle.load(open(path.replace('.json', 'item_rid'), 'rb'))
    train_item_rid = pickle.load(open(path.replace('.json', 'train_item_rid'), 'rb'))

    user_rating = pickle.load(open(path.replace('.json', 'user_rating'), 'rb'))
    train_user_rating = pickle.load(open(path.replace('.json', 'train_user_rating'), 'rb'))
    item_rating = pickle.load(open(path.replace('.json', 'item_rating'), 'rb'))
    train_item_rating = pickle.load(open(path.replace('.json', 'train_item_rating'), 'rb'))

    max_len_u    = 0
    max_len_i    = 0
    max_review   = 0
    min_review   = 5
    u_text       = {}
    train_u_text = {}
    i_text       = {}
    train_i_text = {}
    u_ids        = {}
    i_ids        = {}
    train_u_ids  = {}
    train_i_ids  = {}
    u_ratings     = {}
    i_ratings     = {}
    train_u_ratings = {}
    train_i_ratings = {}

    for urid, review in user_reviews.items():
        line_cleaned = []
        for sen in review[:REVIEW_SIZE]:
            max_review = max(max_review, len(review))
            min_review = min(min_review, len(review))
            now = clean_str(str(sen)).split(' ')
            max_len_u = max(max_len_u, len(now))
            line_cleaned.append(now)
        u_text[int(urid)] = line_cleaned
    for urid, review in train_user_reviews.items():
        line_cleaned = []
        for sen in review[:REVIEW_SIZE]:
            now = clean_str(str(sen)).split(' ')
            line_cleaned.append(now)
        train_u_text[int(urid)] = line_cleaned

    for irid, review in item_reviews.items():
        line_cleaned = []
        for sen in review[:REVIEW_SIZE]:
            max_review = max(max_review, len(review))
            min_review = min(min_review, len(review))
            now = clean_str(str(sen)).split(' ')
            max_len_i = max(max_len_i, len(now))
            line_cleaned.append(now)
        i_text[int(irid)] = line_cleaned
    for irid, review in train_item_reviews.items():
        line_cleaned = []
        for sen in review[:REVIEW_SIZE]:
            now = clean_str(str(sen)).split(' ')
            line_cleaned.append(now)
        train_i_text[int(irid)] = line_cleaned

    for urid, ids in user_rid.items():
        id = []
        for i in ids[:REVIEW_SIZE]:
            id.append(i)
        u_ids[int(urid)] = id
    for urid, ids in train_user_rid.items():
        id = []
        for i in ids[:REVIEW_SIZE]:
            id.append(i)
        train_u_ids[int(urid)] = id

    for irid, ids in item_rid.items():
        id = []
        for i in ids[:REVIEW_SIZE]:
            id.append(i)
        i_ids[int(irid)] = id
    for irid, ids in train_item_rid.items():
        id = []
        for i in ids[:REVIEW_SIZE]:
            id.append(i)
        train_i_ids[int(irid)] = id

    for urid, ratings in user_rating.items():
        rating = []
        for i in ratings[:REVIEW_SIZE]:
            rating.append(i)
        u_ratings[int(urid)] = rating
    for urid, ratings in train_user_rating.items():
        rating = []
        for i in ratings[:REVIEW_SIZE]:
            rating.append(i)
        train_u_ratings[int(urid)] = rating

    for irid, ratings in item_rating.items():
        rating = []
        for i in ratings[:REVIEW_SIZE]:
            rating.append(i)
        i_ratings[int(irid)] = rating
    for irid, ratings in train_item_rating.items():
        rating = []
        for i in ratings[:REVIEW_SIZE]:
            rating.append(i)
        train_i_ratings[int(irid)] = rating


    para={}
    para['user_num'] = len(u_text)
    para['item_num'] = len(i_text)
    para['user_length'] = max(max_len_u, max_len_i)
    para['item_length'] = max(max_len_u, max_len_i)
    para['review_size'] = REVIEW_SIZE
    print(para, max_review, min_review)
    para['u_text'] = u_text
    para['train_u_text'] = train_u_text
    para['i_text'] = i_text
    para['train_i_text'] = train_i_text

    para['u_id'] = u_ids
    para['train_u_id'] = train_u_ids
    para['i_id'] = i_ids
    para['train_i_id'] = train_i_ids

    para['u_rating'] = u_ratings
    para['train_u_rating'] = train_u_ratings
    para['i_rating'] = i_ratings
    para['train_i_rating'] = train_i_ratings

    pickle.dump(para, open(path.replace('.json', '.para'), 'wb'))
    print("OVER")

def clean_str(string):
    string = re.sub(r"[^A-Za-z]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()

if __name__ == "__main__":
    main(DATA_PATH_MUSIC)
    #main(DATA_PATH_Instrument)
    #main(DATA_PATH_Game)
    #main(DATA_PATH_Product)
    #main(DATA_PATH_Food)